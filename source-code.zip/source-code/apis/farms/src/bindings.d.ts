export {}

declare global {
  const FARMS: KVNamespace
  const KV_CACHE: boolean
  const FORCE_UPDATE_KEY: string
}
